import os
import configparser

from pathlib import Path


class GlobalVar(object):
    """ Define for global variables. """
    CONFIG_FILENAME = "config.ini"


def get_config_data(section, key):
    """ Get config value.

        :param str section: a configuration section
        :param str key: a configuration key
    """
    path = Path(GlobalVar.CONFIG_FILENAME)
    config = configparser.ConfigParser()
    config.read(path, encoding='utf-8')
    return config[section][key]
