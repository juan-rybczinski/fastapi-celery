from abc import ABC, abstractmethod

import numpy as np
from PIL import Image

import tensorflow as tf
from tensorflow.keras.applications import resnet50

from mine.replayed import util

img_height = 512
img_width = 512

resize_height = 3000

class_names = util.get_config_data('system', 'model_labels').split(',')
real_index = class_names.index('real')
print_index = class_names.index('print')
screen_index = class_names.index('screen')

gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
    try:
        gpu_memory = int(util.get_config_data('system', 'gpu_memory'))
        tf.config.experimental.set_virtual_device_configuration(
            gpus[0],
            [tf.config.experimental.VirtualDeviceConfiguration(memory_limit=gpu_memory)])
        tf.config.experimental.set_visible_devices(gpus[0], 'GPU')
    except RuntimeError as e:
        print(e)


def _resize_image(img):
    resize_width = int(img.size[0] * (resize_height / img.size[1]))
    return img.resize((resize_width, resize_height))


def _preprocess(img, img_shape=(224, 224), crop=False, left=False):
    """ Common preprocessing function of an input image

    :param file: a file object(e.g. from Flask request) or a file path
    :param img_shape: an image shape to resize
    :param crop: whether to center crop
    :param left: whether to left crop
    :return: a preprocessed image
    """
    h = img.size[1] / 2
    w = img.size[0] / 2
    if crop and left:
        h -= 600
        w -= 600
        img = img.crop((w - 256, h - 256, w + 256, h + 256))  # left
    elif crop:
        img = img.crop((w - 256, h - 256, w + 256, h + 256))  # center

    img_array = tf.keras.preprocessing.image.img_to_array(img)
    if img_array.shape[0] != img_shape[0] or img_array.shape[1] != img_shape[1]:
        img_array = tf.image.resize(img_array, img_shape).numpy()
    img_array = tf.expand_dims(img_array, 0).numpy()  # Create a batch

    return resnet50.preprocess_input(img_array)


def _predict(img, model, class_name):
    """ Common prediction function for a preprocessed image

    :param img: a preprocessed image
    :param model: a model object
    :param class_name: an array of model labels
    :return: (prediction label, probability of real, probabilities of every label)
    """
    if type(img) == list:
        predictions = model(img)
    else:
        predictions = model.predict(img)

    score = tf.nn.softmax(predictions[0])

    prediction = np.argmax(score)
    label = class_name[prediction]
    prob = f"{round(100 * score.numpy()[real_index], 6)}%"

    return label, prob, score.numpy()


def _check(prediction):
    """ Common function to return True only in the case of real

    :param prediction: a prediction result
    :return: whether to be replayed
    """
    if prediction == "real":
        return True
    else:
        return False


def _response(result, size):
    """ Common function to create a return object

    :param result: whether to be replayed
    :return: {prediction, probability of real}
    """
    return {
        "prediction": _check(class_names[np.argmax(result)]),
        "probability": f"{round(100 * result[real_index], 6)}%",
        "print": f"{round(100 * result[print_index], 6)}%",
        "screen": f"{round(100 * result[screen_index], 6)}%",
        "size": str(size)
    }


class BasePrediction(ABC):
    """ Abstraction of Prediction Class """

    @abstractmethod
    def _preprocess(self, img):
        """ Set input properties after preprocessing an input image

        :param img: an input image
        :return:
        """
        pass

    @abstractmethod
    def run(self, img):
        """ Execute a prediction from an input image

        :param img: an input image
        :return: a response object
        """
        pass


class Model9(BasePrediction):
    """ Model9 Class """

    def __init__(self, path):
        """ Initializing Model9 Class
        - Set model properties respectively after loading models using model path
        :param path: a model path
        """
        super(Model9, self).__init__()
        self.model7 = tf.keras.models.load_model(f"{path}/7")
        self.model8 = tf.keras.models.load_model(f"{path}/8")

    def _preprocess(self, img):
        """ Preprocess an input image and set it to input properties

        :param img: an input image
        :return:
        """
        img = Image.open(img)
        self.size = img.size

        if img.size[1] < resize_height:
            img = _resize_image(img)

        self.input7 = _preprocess(img, img_shape=(512, 512))
        self.input8_1 = _preprocess(img, img_shape=(512, 512), crop=True)
        self.input8_2 = _preprocess(img, img_shape=(512, 512), crop=True, left=True)

    def run(self, img):
        """ Execute a prediction and return the result as the form of response

        :param img: an input image
        :return: {prediction, probability of real}
        """
        self._preprocess(img)

        _, _, result7 = _predict(self.input7, self.model7, class_names)

        _, _, result8_1 = _predict(self.input8_1, self.model8, class_names)
        _, _, result8_2 = _predict(self.input8_2, self.model8, class_names)
        result8 = (result8_1 + result8_2) / 2

        result9 = (np.array(result7) + np.array(result8)) / 2

        return _response(result9, self.size)

    def run_by_path(self, path):
        """ Execute a prediction of an image located in the path

        :param path: an image path
        :return: {prediction, probability of real}
        """
        return self.run(path)


class Model14(BasePrediction):
    """ Model14 Class """

    def __init__(self, path):
        """ Initializing Model14 Class
        - Set model property after loading the model using model path
        :param path: a model path
        """
        super(Model14, self).__init__()
        self.model = tf.keras.models.load_model(path)

    def _preprocess(self, img):
        """ Preprocess an input image and set it to input properties

        :param img: an input image
        :return:
        """
        img = Image.open(img)
        self.size = img.size

        if img.size[1] < resize_height:
            img = _resize_image(img)

        self.input_full = _preprocess(img, img_shape=(512, 512))
        self.input_center = _preprocess(img, img_shape=(512, 512), crop=True)

    def run(self, img):
        """ Execute a prediction and return the result as the form of response

        :param img: an input image
        :return: {prediction, probability of real}
        """
        self._preprocess(img)

        _, _, result = _predict([self.input_full, self.input_center], self.model, class_names)

        return _response(result, self.size)
