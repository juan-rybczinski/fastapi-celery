from mine.replayed.model.prediction import Model9, Model14


class Detection(object):
    """ Detection Engine Class """

    def __init__(self, number, path):
        """ Initialize Detection class using a model number and a model path

        :param number: a model number
        :param path: a model path
        """
        self._load_model(number, path)

    def _load_model(self, number, path):
        """ Set model property after loading model using model number and path

        :param number: a model number
        :param path: a model path
        :return:
        """
        if number == "9":
            self.model = Model9(path)
        elif number == "14":
            self.model = Model14(path)

    def run(self, img):
        """ Execute a detection of an image

        :param img: an input image
        :return: a detection result
        """
        return self.model.run(img)

    def run_by_path(self, path):
        """

        :param path: an image path
        :return: a detection result
        """
        return self.model.run_by_path(path)
